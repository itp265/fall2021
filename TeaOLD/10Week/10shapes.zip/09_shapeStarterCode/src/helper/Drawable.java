package helper;

public interface Drawable {
public void drawInAscii();
public void draw();
}
